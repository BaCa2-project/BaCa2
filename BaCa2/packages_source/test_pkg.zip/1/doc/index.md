# Liczby Fibonacciego
Program ma wypisywać n pierwszych liczb Fibonacciego
Liczby mają zostać wypisane w osobnych liniach, każdy n-ty wynik ma zostać 
odzielony znakiem nowej linii (dodatkowym).\
Wejście: cyfra n oznaczająca ile zestawów liczb Fibonacciego będzie trzeba
obliczyć. Kolejno zostaje podane n cyfr oznaczających ile
liczb Fibonacciego trzeba będzie wypisać.
### Example
IN:\
3\
2\
4\
7

OUT:\
0\
1

0\
1\
1\
2

0\
1\
1\
2\
3\
5\
8
